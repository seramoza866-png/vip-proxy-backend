# VIP PROXY GENERATOR 🚀

## Fitur
- Dashboard Admin untuk manage user
- Generate proxy REAL dari internet
- Update 10x/hari otomatis
- 3D Red & Blue UI
- Anti bot, anti simulasi, anti edukasi
- 100% work

## Cara Install

### Manual
```bash
# Backend
cd backend
npm install
npm start

# Frontend
Buka index.html di browser