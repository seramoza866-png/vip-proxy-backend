const mongoose = require('mongoose');

const ProxySchema = new mongoose.Schema({
  ip: {
    type: String,
    required: true
  },
  port: {
    type: String,
    required: true
  },
  protocol: {
    type: String,
    default: 'http'
  },
  country: {
    type: String,
    default: 'Unknown'
  },
  speed: {
    type: Number,
    default: 100
  },
  isActive: {
    type: Boolean,
    default: true
  },
  lastChecked: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Proxy', ProxySchema);