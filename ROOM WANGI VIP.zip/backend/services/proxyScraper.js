const axios = require('axios');

async function fetchRealProxies() {
  const sources = [
    'https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=10000&country=all',
    'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt',
    'https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt',
    'https://raw.githubusercontent.com/hookzof/socks5_list/master/proxy.txt',
    'https://raw.githubusercontent.com/roosterkid/openproxylist/main/HTTP_RAW.txt'
  ];
  
  let allProxies = [];
  
  for (const url of sources) {
    try {
      const response = await axios.get(url, { 
        timeout: 15000,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
      });
      
      const lines = response.data.split('\n').filter(line => line.trim());
      
      for (const line of lines) {
        let ip, port;
        if (line.includes(':')) {
          [ip, port] = line.trim().split(':');
          if (ip && port && ip.split('.').length === 4) {
            allProxies.push({
              ip: ip.trim(),
              port: port.trim(),
              protocol: 'http',
              country: 'Mixed',
              speed: Math.floor(Math.random() * 150) + 30,
              isActive: true
            });
          }
        }
      }
    } catch (error) {
      console.log(`❌ Failed to fetch from ${url}`);
    }
  }
  
  // Remove duplicates
  const uniqueProxies = [];
  const seen = new Set();
  for (const proxy of allProxies) {
    const key = `${proxy.ip}:${proxy.port}`;
    if (!seen.has(key)) {
      seen.add(key);
      uniqueProxies.push(proxy);
    }
  }
  
  console.log(`✅ Fetched ${uniqueProxies.length} unique proxies`);
  return uniqueProxies.slice(0, 300);
}

async function testProxySpeed(proxy) {
  try {
    const start = Date.now();
    await axios.get('http://httpbin.org/ip', {
      proxy: {
        host: proxy.ip,
        port: parseInt(proxy.port),
        protocol: proxy.protocol
      },
      timeout: 5000
    });
    const speed = Date.now() - start;
    proxy.speed = speed;
    proxy.isActive = true;
    return proxy;
  } catch (error) {
    proxy.isActive = false;
    return proxy;
  }
}

module.exports = { fetchRealProxies, testProxySpeed };