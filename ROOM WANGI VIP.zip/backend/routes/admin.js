const express = require('express');
const bcrypt = require('bcryptjs');
const { adminAuth } = require('../middleware/auth');
const User = require('../models/User');
const Proxy = require('../models/Proxy');

const router = express.Router();

// Create user
router.post('/create-user', adminAuth, async (req, res) => {
  try {
    const { username, password, expiredDays } = req.body;
    
    if (!username || !password) {
      return res.status(400).json({ error: 'Username and password required' });
    }

    const existing = await User.findOne({ username });
    if (existing) {
      return res.status(400).json({ error: 'Username already exists' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const expired = new Date();
    expired.setDate(expired.getDate() + (expiredDays || 30));

    const user = new User({
      username,
      password: hashedPassword,
      expired,
      isAdmin: false
    });

    await user.save();
    res.json({ 
      message: 'User created successfully',
      user: {
        username: user.username,
        expired: user.expired
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get all users
router.get('/users', adminAuth, async (req, res) => {
  try {
    const users = await User.find({}, '-password');
    res.json(users);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Delete user
router.delete('/user/:id', adminAuth, async (req, res) => {
  try {
    await User.findByIdAndDelete(req.params.id);
    res.json({ message: 'User deleted' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Force update proxies
router.post('/force-update', adminAuth, async (req, res) => {
  try {
    const { fetchRealProxies } = require('../services/proxyScraper');
    const proxies = await fetchRealProxies();
    await Proxy.deleteMany({});
    await Proxy.insertMany(proxies);
    res.json({ message: `Updated ${proxies.length} proxies` });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;