const express = require('express');
const { auth } = require('../middleware/auth');
const Proxy = require('../models/Proxy');

const router = express.Router();

// Get all proxies
router.get('/proxies', auth, async (req, res) => {
  try {
    const proxies = await Proxy.find({ isActive: true })
      .sort({ speed: 1 })
      .limit(50);
    
    const formatted = proxies.map(p => ({
      ip: p.ip,
      port: p.port,
      protocol: p.protocol,
      speed: p.speed,
      string: `${p.protocol}://${p.ip}:${p.port}`
    }));

    res.json(formatted);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get single fastest proxy
router.get('/proxy/quick', auth, async (req, res) => {
  try {
    const proxy = await Proxy.findOne({ isActive: true })
      .sort({ speed: 1 });
    
    if (!proxy) {
      return res.status(404).json({ error: 'No proxy available' });
    }

    res.json({
      ip: proxy.ip,
      port: proxy.port,
      protocol: proxy.protocol,
      full: `${proxy.protocol}://${proxy.ip}:${proxy.port}`,
      speed: proxy.speed
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Check proxy status
router.get('/status', auth, async (req, res) => {
  try {
    const total = await Proxy.countDocuments();
    const active = await Proxy.countDocuments({ isActive: true });
    const last = await Proxy.findOne().sort({ createdAt: -1 });
    
    res.json({
      total,
      active,
      lastUpdate: last ? last.createdAt : null,
      updateSchedule: '10x per day'
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;