const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');

const router = express.Router();

router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    
    const user = await User.findOne({ username });
    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    if (user.expired < new Date()) {
      return res.status(403).json({ error: 'Account expired' });
    }

    const token = jwt.sign(
      { id: user._id, admin: user.isAdmin },
      process.env.JWT_SECRET || 'VIP2026_SUPER_SECRET',
      { expiresIn: '7d' }
    );

    res.json({
      token,
      isAdmin: user.isAdmin,
      username: user.username,
      expired: user.expired
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;