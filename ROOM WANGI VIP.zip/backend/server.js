require('dotenv').config();
const express = require('express');
const cors = require('cors');
const cron = require('node-cron');
const connectDB = require('./config/database');
const { fetchRealProxies } = require('./services/proxyScraper');
const Proxy = require('./models/Proxy');

// Routes
const authRoutes = require('./routes/auth');
const adminRoutes = require('./routes/admin');
const proxyRoutes = require('./routes/proxy');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Connect Database
connectDB();

// Routes
app.use('/api', authRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api', proxyRoutes);

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'OK', time: new Date() });
});

// Auto update proxies every 2.4 hours (10x/day)
async function updateProxies() {
  console.log('🔄 Updating proxies...');
  try {
    const proxies = await fetchRealProxies();
    await Proxy.deleteMany({});
    await Proxy.insertMany(proxies);
    console.log(`✅ Updated ${proxies.length} proxies at ${new Date()}`);
  } catch (error) {
    console.error('❌ Proxy update failed:', error);
  }
}

// Schedule: setiap 2.4 jam (10x sehari)
cron.schedule('0 */2 * * *', updateProxies);
// First run
updateProxies();

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 VIP Proxy Server running on port ${PORT}`);
  console.log(`⚡ Mode: REAL API | Updates: 10x/day`);
});