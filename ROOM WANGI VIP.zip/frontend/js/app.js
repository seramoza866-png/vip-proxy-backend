import { init3DBackground } from './3dbackground.js';

let token = '';
let isAdmin = false;

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    init3DBackground();
});

// Login function
window.login = async function() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    if (!username || !password) {
        showResult('❌ Masukkan username dan password', '#ff0040');
        return;
    }
    
    try {
        const response = await fetch('http://localhost:3000/api/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });
        
        const data = await response.json();
        
        if (data.token) {
            token = data.token;
            isAdmin = data.isAdmin;
            
            showResult(`✅ Login berhasil! ${isAdmin ? '👑 Admin' : '👤 User'}`, '#00ff88');
            
            if (isAdmin) {
                document.getElementById('adminPanel').classList.add('show');
            }
            
            getProxies();
        } else {
            showResult(`❌ ${data.error || 'Login gagal'}`, '#ff0040');
        }
    } catch (error) {
        showResult('❌ Server offline atau error', '#ff0040');
    }
};

// Get proxies
window.getProxies = async function() {
    if (!token) {
        showResult('⚠️ Login dulu!', '#ff8800');
        return;
    }
    
    try {
        const response = await fetch('http://localhost:3000/api/proxies', {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        
        const data = await response.json();
        
        if (Array.isArray(data) && data.length > 0) {
            let html = '<div style="font-weight:700;color:#0066ff;margin-bottom:15px;">🔥 PROXY LIVE (REAL)</div>';
            html += `<div style="font-size:0.7em;color:#8899bb;margin-bottom:10px;">Total: ${data.length} proxy aktif</div>`;
            
            data.slice(0, 30).forEach((p, i) => {
                html += `<div style="padding:8px 0;border-bottom:1px solid rgba(255,255,255,0.05);font-size:0.75em;display:flex;justify-content:space-between;">
                    <span>${i+1}. ${p.string || `${p.protocol}://${p.ip}:${p.port}`}</span>
                    <span style="color:#00ff88;">⚡${p.speed || 100}ms</span>
                </div>`;
            });
            
            html += `<div style="margin-top:15px;padding:10px;background:rgba(0,255,136,0.1);border-radius:10px;font-size:0.7em;color:#00ff88;">
                ✅ Update otomatis 10x/hari | 100% work anti bot
            </div>`;
            
            document.getElementById('proxyResult').innerHTML = html;
            document.getElementById('proxyResult').classList.add('show');
        } else {
            showResult('⏳ Proxy sedang diupdate... Tunggu sebentar', '#ff8800');
        }
    } catch (error) {
        showResult('❌ Gagal mengambil proxy', '#ff0040');
    }
};

// Create user (admin)
window.createUser = async function() {
    if (!token || !isAdmin) {
        alert('❌ Admin only!');
        return;
    }
    
    const username = document.getElementById('newUser').value;
    const password = document.getElementById('newPass').value;
    const expiredDays = parseInt(document.getElementById('expireDays').value) || 30;
    
    if (!username || !password) {
        alert('❌ Isi semua field!');
        return;
    }
    
    try {
        const response = await fetch('http://localhost:3000/api/admin/create-user', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ username, password, expiredDays })
        });
        
        const data = await response.json();
        
        if (data.message) {
            alert(`✅ ${data.message}\nUsername: ${username}\nExpired: ${data.user.expired}`);
            document.getElementById('newUser').value = '';
            document.getElementById('newPass').value = '';
        } else {
            alert(`❌ ${data.error || 'Gagal create user'}`);
        }
    } catch (error) {
        alert('❌ Server error');
    }
};

// Show result function
function showResult(message, color = '#ffffff') {
    const resultDiv = document.getElementById('proxyResult');
    resultDiv.innerHTML = `<div style="color:${color};">${message}</div>`;
    resultDiv.classList.add('show');
}

// Auto refresh proxy every 2 minutes
setInterval(() => {
    if (token) getProxies();
}, 120000);

// Keyboard support
document.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
        const active = document.activeElement;
        if (active.id === 'username' || active.id === 'password') {
            login();
        }
    }
});