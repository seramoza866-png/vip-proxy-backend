// 3D Particle System - Red & Blue Theme
export function init3DBackground() {
    const canvas = document.getElementById('canvas-bg');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    
    const particles = [];
    const numParticles = 250;
    
    for (let i = 0; i < numParticles; i++) {
        particles.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            z: Math.random() * 1500,
            size: Math.random() * 4 + 1,
            speed: Math.random() * 3 + 0.5,
            color: Math.random() > 0.5 ? '#ff0040' : '#0066ff'
        });
    }
    
    function animate() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        // Gradient background
        const grd = ctx.createRadialGradient(
            canvas.width/2, canvas.height/2, 0,
            canvas.width/2, canvas.height/2, canvas.width/1.5
        );
        grd.addColorStop(0, '#0a0a2a');
        grd.addColorStop(0.5, '#150015');
        grd.addColorStop(1, '#000000');
        ctx.fillStyle = grd;
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        for (const p of particles) {
            p.z -= p.speed;
            if (p.z < 0) {
                p.z = 1500;
                p.x = Math.random() * canvas.width;
                p.y = Math.random() * canvas.height;
            }
            
            const scale = 1500 / p.z;
            const x = (p.x - canvas.width/2) * scale + canvas.width/2;
            const y = (p.y - canvas.height/2) * scale + canvas.height/2;
            const size = p.size * scale;
            
            const alpha = Math.min(1, (1500 - p.z) / 1500);
            
            ctx.beginPath();
            ctx.arc(x, y, size, 0, Math.PI * 2);
            ctx.fillStyle = p.color + Math.floor(alpha * 150).toString(16).padStart(2, '0');
            ctx.shadowColor = p.color;
            ctx.shadowBlur = size * 3;
            ctx.fill();
        }
        
        requestAnimationFrame(animate);
    }
    
    animate();
    
    window.addEventListener('resize', () => {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    });
}